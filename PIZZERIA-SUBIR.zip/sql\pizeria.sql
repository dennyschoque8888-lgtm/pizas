CREATE DATABASE IF NOT EXISTS pizeria CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pizeria;

DROP TABLE IF EXISTS mensajes;
DROP TABLE IF EXISTS horario;
DROP TABLE IF EXISTS testimonios;
DROP TABLE IF EXISTS menu;
DROP TABLE IF EXISTS chefs;

CREATE TABLE chefs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  especialidad VARCHAR(120) NOT NULL,
  foto VARCHAR(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE menu (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(255) NOT NULL,
  precio DECIMAL(8,2) NOT NULL,
  foto VARCHAR(200) NOT NULL,
  del_dia TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE testimonios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  comentario TEXT NOT NULL,
  estrellas TINYINT NOT NULL DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE horario (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dia VARCHAR(40) NOT NULL,
  horas VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE mensajes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  correo VARCHAR(120) NOT NULL,
  mensaje TEXT NOT NULL,
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO chefs (nombre, especialidad, foto) VALUES
('Mateo Vargas', 'Maestro pizzero', 'img/chef1.jpg'),
('Andrés Choque', 'Horno de leña', 'img/chef2.jpg'),
('Carlos Mamani', 'Masas y salsas', 'img/chef3.jpg');

INSERT INTO menu (nombre, descripcion, precio, foto, del_dia) VALUES
('Margherita', 'Salsa de tomate, mozzarella y albahaca fresca.', 45, 'img/pizza1.jpg', 1),
('Pepperoni', 'Mozzarella y pepperoni horneado.', 52, 'img/pizza2.jpg', 1),
('Hawaiana', 'Pollo, piña, mozzarella y cilantro.', 50, 'img/pizza3.jpg', 0),
('Extra queso', 'Mucha mozzarella fundida con pepperoni.', 58, 'img/pizza4.jpg', 1),
('Rúcula', 'Salsa de tomate, rúcula y queso fresco.', 60, 'img/pizza5.jpg', 0),
('Pepperoni familiar', 'Pizza grande de pepperoni para compartir.', 65, 'img/pizza6.jpg', 0);

INSERT INTO testimonios (nombre, comentario, estrellas) VALUES
('Ana Gutiérrez', 'La masa está crujiente y el queso se estira rico. Volvemos cada viernes.', 5),
('Luis Choque', 'Pedimos la del día y llegó caliente. Buena atención.', 5),
('Valeria Rojas', 'La hawaiana nos gustó mucho. El local es cómodo para la familia.', 4);

INSERT INTO horario (dia, horas) VALUES
('Lunes a jueves', '12:00 - 22:30'),
('Viernes', '12:00 - 23:30'),
('Sábado', '12:00 - 23:30'),
('Domingo', '12:00 - 21:00');
